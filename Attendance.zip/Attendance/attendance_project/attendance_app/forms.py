
# attendance_app/forms.py

from django import forms
from .models import Attendance

class AddAttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['roll_number', 'name', 'date', 'present']

class SearchAttendanceForm(forms.Form):
    date = forms.DateField()
