# attendance_app/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.add_attendance, name='add_attendance'),
    # path('search/', views.search_attendance, name='search_attendance'),
    path('search_attendance.html',views.s, name='hi'),
]