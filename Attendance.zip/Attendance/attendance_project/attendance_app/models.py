# attendance_app/models.py

from django.db import models

class Attendance(models.Model):
    roll_number = models.IntegerField()
    name = models.CharField(max_length=255)
    date = models.DateField()
    present = models.BooleanField()
