# attendance_app/views.py
from django.shortcuts import render, redirect
from .forms import AddAttendanceForm, SearchAttendanceForm
from .models import Attendance

def add_attendance(request):

    
    if request.method == 'POST':
        form = AddAttendanceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_attendance.html')
    else:
        form = AddAttendanceForm()
    return render(request, 'add_attendance.html', {'form': form})

# def search_attendance(request):
#     if request.method == 'POST':
#         form = SearchAttendanceForm(request.POST)
#         if form.is_valid():
#             date = form.cleaned_data['date']
#             attendance = Attendance.objects.filter(date=date)
#             return render(request, 'search_attendance.html', {'attendance': attendance, 'date': date})
#     else:
#         form = SearchAttendanceForm()
#     return render(request, 'search_attendance_form.html', {'form': form})


def s(request):
    return render(request,'search_attendance_form.html')
